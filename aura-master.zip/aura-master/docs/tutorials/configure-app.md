# Configure

1. Configuration data is split into two files:
`/src/assets/data` (configuration data)
1. Update `Meta Tag`, `Title Tag` and [Google Analytics Code](https://analytics.google.com/analytics/web/#/) from [Basic Info](/public/index.html), [manifest.json](/public/manifest.json)


# Next steps

Now your Aura is up configured, learn how to integrate [firebase][firebase] in your app and [deploy][deploy].

[deploy]: deploy.md
