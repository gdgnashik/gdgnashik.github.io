module.exports = {
  pwa: {
    name: 'GDG Web App',
    themeColor: '#4A90E2'
  }
}